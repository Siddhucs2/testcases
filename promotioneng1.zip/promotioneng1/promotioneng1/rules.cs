﻿using System;
namespace promotioneng1
{
    public class rules
    {
        public rules()
        {
        }
    }
}

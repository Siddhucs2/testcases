﻿using System.Collections.Generic;

namespace PromotionEngine.PromotionRules
{
    public class Cart
    {
        public IEnumerable<object> Items { get; internal set; }
    }
}